<?php
$con= mysqli_connect("localhost","root","","project_css326") or die("Error: " . mysqli_error($con));
mysqli_query($con, "SET NAMES 'utf8' "); 
?>